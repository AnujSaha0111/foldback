# Foldback redesign — design decisions

This package is a visual handoff. Open any file in `/screens` through a static server (from the package root: `python3 -m http.server 8765`, then `http://localhost:8765/screens/screen1-landing.html`). Every screen links the four CSS files in `/design-system`. `/assets` holds reference renders of every screen and state, and the logo.

**Instruction to the implementing agent:** build exactly what the HTML shows. The HTML/CSS is the spec; these documents explain *why* and give the numbers. Where a number appears in both, the CSS wins.

| Screen | File | Real route |
|---|---|---|
| Landing | `screens/screen1-landing.html` | `/` |
| Sign in / Create account | `screens/screen2-signin.html` | `/login`, `/signup` |
| New plan (rule screen) + Plans list | `screens/screen3-new-plan.html` | `/plans` |
| Board | `screens/screen4-board.html` | `/plans/[id]` |
| Pay | `screens/screen5-pay.html` | `/pay/[shareId]` |
| Components and states | `screens/screen6-components.html` | n/a (reference) |

Grey "Mockup state" switchers at the top of screens 3, 4 and 5 are for reviewing states. They are **not** part of the product.

---

## 1. What was kept, exactly

- The logo: geometry, colours, fold positions, dark-theme variant. `.logo` in `components.css` is a verbatim copy.
- The brand colours: Sky `#60CDFF`, Sun gradient `#FFB547 → #FF7A1A → #F2501E`, Ink `#000`, Blue `#0070E0`, Navy `#012169`, Warm `#FFF3E6`, Carbon greys.
- IBM Plex Sans and Plex Mono. Square controls (0 radius). Status as a word, never colour alone.
- All product copy and the vocabulary rules (hold, captured/kept, released, not charged; never escrow, guaranteed, bank, wallet).
- Every functional element in `docs/spec/ui.md`: the same routes, fields, buttons, states and helper lines.

## 2. Honest audit of the current design

Scored against the 16 criteria in the brief. Current overall: **5.5 / 10**. The brand is strong; the execution reads as a well-made template.

### First impression (5 seconds)
- **Strength:** the headline is excellent and the Cabin weekend panel explains the product without words.
- **Weakness:** the panel is static. The single most persuasive moment of this product (the last hold landing, the group completing) never happens on screen. Judges look at a hero for ~5 seconds; a static table is not memorable.
- **Weakness:** three equal-weight actions in the hero (Try it as a guest, Sign in, Create account) split attention. Conversion pages have one primary and one secondary.
- **Fix:** Maya's hold lands 2.8 s after load: her tag pops from Waiting to Held, the last square fills, the total counts up from $240.00 to $320.00, and "1 to go" becomes "Everyone's in". A live countdown sits under the panel. Create account moved to a text link.

### Visual hierarchy
- **Weakness:** the board screen gives the same weight to the title, three action buttons, a status line, the table and two cards. Nothing tells the eye where to land. "3 of 4 held · Now · Total" is a single grey line, though it is the most important information on the page.
- **Fix:** a four-cell stat strip (Holds, Held so far, Now, Deadline) right under the title, with progress squares and a meter. The demo clock becomes a labelled group with its helper text, and the one orange action (Resolve now) is pushed to the right edge.

### Premium feel
- **Weakness:** flat white surfaces with grey table headers look like Carbon defaults. Shadows are single-layer and grey-black, which reads cheap next to the saturated sky.
- **Fix:** layered, navy-tinted elevation (`--shadow-1…4`), real frosted glass only where colour sits behind it, a film grain on gradient bands so they never band, and slow ambient light drifting behind the hero glass (28–32 s loops).

### Trust (fintech)
- **Weakness:** the reassurance ("a hold, not a charge") only appears in body copy. Nothing near the primary action says what will happen to money.
- **Fix:** a three-item trust row under the hero CTA (A PayPal hold, not a charge / Captured only if everyone's in / Otherwise released). On Pay, a lock line under the button. The phone scene shows the "held" receipt state. Nothing is fabricated: no fake logos, testimonials or statistics.

### Conversion
- One sun-orange action per view, everywhere. The hero CTA is 52 px, and the nav duplicates it in ink. The final CTA band uses ink, because the orange footer sits right under it.

### User flows and information architecture
- **Weakness:** New plan gives no sense of progress; after "Read the plan" the user can't see why the assistant decided anything.
- **Fix:** a 4-step flow indicator (Paste → Read → Confirm → Share links). After reading, the chat becomes a **transcript with the evidence highlighted**; hovering any term lights up the exact line it came from. This is the single best trust feature in the product, and it costs one hover handler.
- The Plans table gains a deadline subline, progress squares and a total, so the list answers "which plan needs me?" without opening any of them.

### Accessibility
- All text pairs meet WCAG AA (ratios listed in `colors.css`). Focus is visible on every control (2 px ring with offset). Statuses are words. Motion stops under `prefers-reduced-motion` (everything rests in its final state). Touch targets are at least 44 px. The board rows are focusable and selectable with Enter or Space.

### Typography
- **Weakness:** headings at weight 300 next to body text at 400 felt washed out at small sizes. Tracking was the same at every size.
- **Fix:** tracking tightens as size grows (−0.038em display → −0.012em h3). `text-wrap: balance` on headings, `pretty` on paragraphs. Money uses mono with `tabular-nums slashed-zero`, so columns never jitter during the count-up.

### Spacing
- **Weakness:** sections used 96–128 px of vertical padding, with generous gaps inside components too. It felt like a template, not a product.
- **Fix:** a humanized rhythm. 8–12 px between things that belong together, 48–96 px between ideas, never more. Section padding is `clamp(56px, …, 96px)`.

### Consistency
- One token set, one component file, one motion vocabulary. Every screen uses the same app header, panels, tags, buttons and footer.

### Interaction and micro-interactions
- **Weakness:** almost no feedback. Buttons changed colour; nothing else responded.
- **Fix:** every interactive element responds (see `animation-specs.md`):
  - Press scales to .97.
  - Arrows nudge 3 px on hover.
  - Hover highlights appear instantly and fade out over 150 ms.
  - Copy pay link morphs into Copied with a blur cross-fade.
  - Focus draws an underline from the centre.
  - Failed sign-in shakes once.
  - The brand fold deepens on hover.

### Motion
- Purposeful only, using transform, opacity, filter and clip-path. Large reveals take 700–900 ms on expo or quart ease-out; UI responses take 80–240 ms. **Nothing decorative moves on the Pay page.** It is the page that asks for money; calm reads as safe.

### Mobile
- The Pay page is designed at 375 px first: "This is a hold, not a charge." and the button sit above the fold, and "Who's in" moves below the action. The board scrolls inside its own frame. The nav becomes a sheet that wipes down with staggered links. The dialog becomes a bottom sheet.

### Demo impact
- The three moments a judge will remember:
  1. The hero hold landing.
  2. The phone turning to face you as Maya's hold arrives.
  3. On the board, "Advance to deadline" gliding the Now line along the timeline, then Resolve.

  All three are reproducible on cue (there's a Replay link on the hero).

## 3. Per-screen decisions

### Landing (`screen1`)
| Element | Before | After | Why |
|---|---|---|---|
| Nav | White bar; the logo's sky block vanished on sky | Fixed frosted bar (55% white, rising to 86% on scroll) | Logo legibility; it stays through every scene |
| Headline | Static | Words rise through a mask with 8 px blur, 55 ms stagger | The first motion sets the quality bar |
| Hero CTAs | 3 equal actions | Sun primary, line secondary, text link | One decision |
| Cabin panel | Static glass | Tilts toward the cursor (≤4°), spotlight follows, Maya's hold lands, countdown ticks | Shows the product working |
| Phone scene | Phone fixed, words slide | Phone rotates from 22°/−26° to flat as you scroll; at 62% Maya's tag flips to Held and the receipt appears | Shows the friend's side of the product |
| How it works | 4 rules | Sticky intro plus a progress line that fills as you scroll; step dots fill when reached | Scannable, and shows where you are |
| Compare | Two equal panels | "Hold now" lifted 8 px with a navy shadow; icons per line | Says which option wins without saying it |
| Kept / Released | Static blocks | Slide together on scroll; folds deepen on hover | The brand fold becomes an interaction |
| Board peek | Static | Bars grow in with stagger; deadline in orange, grace dashed | Previews the real board |

### Sign in (`screen2`)
- Tabs (Sign in / Create account) on one URL-addressable page with a sliding ink bar. This removes a page load between the two.
- Password Show/Hide, a strength meter on create (turns green at 10 characters), and an error that shakes the form once and draws a red underline.
- The art panel keeps "Three holds in. One to go." The squares drop in. A glass card shows the real hold sentence instead of a decorative illustration.

### New plan (`screen3`)
- Flow indicator, transcript-with-evidence, skeleton while reading (the layout is known, so a skeleton is the right choice), clarify state, and a terms list that staggers in.
- The orange action is **Confirm these terms** only. Read the plan is ink.
- Reset demo data opens a dialog that becomes a bottom sheet on phones.

### Board (`screen4`)
- Stat strip, demo clock group, a 7-day timeline (Wed 4 → Tue 10) so the bars show *when* each hold arrived.
- Markers: Now (blue), Deadline (orange, the one thing that matters), Grace ends (dashed ink). Labels sit in a footer band so they never collide with the day headers.
- Selecting a row (or a bar) swaps the Person card with a 400 ms blur-rise.
- Assistant: typing indicator (three squares), tool lines, a draft quote with Copy, and a proposal with Approve / Dismiss. Approving moves the Now line.
- States: Collecting, Kept (green callout), Released (neutral callout), Paused (full-width yellow banner with Check payment), Assistant unavailable (warning in the card; everything else keeps working).
- Resolve now is honest: before grace ends it says "Nothing to resolve yet…" instead of pretending.

### Pay (`screen5`)
- The amount is set large with small raised cents (`$80.00`). The progress summary and the action come **before** the list of people.
- Ten states, each with exact copy from `ui.md`. The state change is a 160 ms fade and nothing else.

## 4. What makes this more likely to win

1. **It demonstrates the mechanism instead of describing it.** Every hero-level visual is the product's own state machine (Waiting → Held → Everyone's in → Kept/Released) animated with real copy.
2. **Explainability as UI.** The evidence highlight on New plan shows judges exactly why the AI produced each term. Most AI demos hide this.
3. **Restraint where money moves.** A still Pay page next to an expressive landing reads like a team that understands fintech, not one that discovered animation libraries.
4. **A brand you can feel.** The fold is now a hover interaction, the progress squares are the loader, and the four squares recur from hero to sign-in to empty states.
5. **Demo choreography.** Replay on the hero, Advance to deadline gliding the Now line, Approve on a proposal moving the board. Each is a 3-second, on-cue clip for the video.

## 5. Scorecard

| Criterion | Current | Redesign |
|---|---|---|
| First impression | 6 | 9 |
| Visual hierarchy | 5 | 8.5 |
| Premium feel | 5 | 8.5 |
| Trust | 6 | 9 |
| Conversion | 5 | 8 |
| Flows and IA | 6 | 8.5 |
| Accessibility | 7 | 9 |
| Typography | 6 | 8.5 |
| Spacing | 5 | 8.5 |
| Consistency | 6 | 9 |
| Interaction | 4 | 9 |
| Motion | 5 | 9 |
| Mobile | 6 | 8.5 |
| Micro-interactions | 3 | 9 |
| Demo impact | 5 | 9 |
| **Overall** | **5.5** | **8.7** |

## 6. Mapping to the real frontend (Next.js + MUI + Emotion)

| Package piece | Real code |
|---|---|
| `colors.css`, `typography.css`, `spacing.css` tokens | `frontend/src/app/globals.css` CSS variables and the MUI theme (palette, typography, shape `borderRadius: 0`) |
| `.btn*` | `src/components/Button` (variants: sun, ink, line, ghost, link, onSky; sizes sm/md/lg) |
| `.field`, `.input` | `src/components/Field` |
| `.tag*` | `src/components/StatusTag` and `Badge` (tone comes from `lib/status.ts`) |
| `.panel*` | a new `Panel` component (glass, solid, raised) |
| `.squares`, `.meter` | a new `HoldProgress` component |
| `[data-reveal]`, `.words` | `src/components/Reveal` (IntersectionObserver, as in the screens) |
| Phone scene `--p` | `src/components/ScrollScene` plus `hooks/useScrollProgress.ts` (already exists) |
| Board | `features/board` (new): grid, bars overlay, markers |
| Dialog | MUI `Dialog` restyled: `PaperProps` radius 12, backdrop blur 6 px, transitions from `animation-specs.md` |

No new dependency is needed. All motion is CSS plus a few lines of vanilla JS. If the team prefers Framer Motion, equivalent spring settings are in `animation-specs.md`, but it would need approval under `quality.md`.

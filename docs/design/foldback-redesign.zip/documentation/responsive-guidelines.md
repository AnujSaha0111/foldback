# Responsive guidelines

## Breakpoints

| Name | Range | Gutter | Notes |
|---|---|---|---|
| Phone | < 600 | 16 | Design and test at 375. The Pay page is designed here first |
| Tablet | 600–1023 | 24 | Test at 768 |
| Desktop | ≥ 1024 | 32 | Test at 1280 (the demo video width) and 1440 |

Component switches: nav collapses under **900**; app header tagline hides under **1100**, crumbs and name under **768**; board side column moves under the board under **1100** and stacks under **700**.

Content width: `--container` 1216 px. Pay: 480 px. Section padding: `clamp(56px, 2rem + 5vw, 96px)`.

## Hard rules

1. **No sideways page scroll at 375, 768, 1280.** Every grid uses `minmax(0, 1fr)` columns (a bare `1fr` lets long content push the column wider than the screen). Wide content (the board, the plans table, segmented controls) scrolls inside its own frame.
2. **Touch targets ≥ 44 px.** Small buttons (36 px) are only used on desktop toolbars or where a 44 px row surrounds them.
3. **The Pay page above the fold at 375×667:** amount, "This is a hold, not a charge.", the condition sentence, progress, and the action button. "Who's in" goes below.
4. **Hover-only effects never hide information.** Tilt, spotlight and the table go-arrow are enhancements; on touch devices (`hover: none`) they are skipped.
5. **Fluid type, not breakpoint jumps.** All headings use `clamp()` (see `typography.css`).
6. **Safe areas.** The Pay footer and bottom-sheet dialog add `env(safe-area-inset-bottom)`; the viewport meta includes `viewport-fit=cover`.

## Per screen

### Landing
| | Phone | Tablet | Desktop |
|---|---|---|---|
| Nav | Logo + menu button; sheet with links and a full-width sun CTA | Same | Links + Sign in + ink CTA |
| Hero | One column: headline (44 px), lead, CTAs full width, trust row wraps, then the panel (money column hidden) | One column, panel full width | Two columns 1.08 : 1 |
| Phone scene | 180 vh, phone 252×520 | 230 vh | 230 vh, phone 292×600 |
| How it works | Intro then steps | Same | Sticky intro (5/12), steps (7/12) |
| Compare | Stacked, 12 px gap | Side by side ≥ 800, new column lifted | Same |
| Kept / Released | Stacked | Side by side ≥ 800 | Same |
| Board peek | Text, then board scrolls inside its frame | Same | 4 : 7 columns |
| Final CTA | Headline, then button | Inline | Inline |

### Sign in
- Phone and tablet: a single column with the form max 400 wide; the art panel is hidden.
- Desktop (≥ 960): form column `minmax(440px, 5fr)` with the art panel at 7fr.

### New plan
- Phone: page head, flow (step numbers only), composer, terms (term rows stack label over value), plans table (Total and Type hidden). The header has no room for Reset demo data, so it moves into the footer (`.only-mobile`) and opens the same dialog as a bottom sheet.
- Desktop (≥ 1024): composer and terms side by side; the terms panel is sticky at top 84.

### Board
- Phone: title + tags wrap; stats 2×2; demo clock buttons wrap with helpers; the board scrolls horizontally (min 760) with the person column sticky; Person, then Assistant.
- Tablet (700–1099): board full width; Person and Assistant side by side.
- Desktop (≥ 1100): board 65% / side 35% (min 320), side column sticky at top 76.

### Pay
- Phone: full-bleed page; the bar and footer are part of the page.
- ≥ 560: a centred card (max 480) with radius 12, `--shadow-4` and 32 px top margin on the app light field.

## QA checklist
- [ ] 375, 768, 1280, 1440: `document.documentElement.scrollWidth === innerWidth`
- [ ] Pay at 375×667: button visible without scrolling
- [ ] Board at 375: person column stays visible while the timeline scrolls
- [ ] Dialog at 375 opens as a bottom sheet, actions full width
- [ ] Nav sheet closes when a link is tapped
- [ ] Dark theme on each screen (`?theme=dark` in the mockups)
- [ ] Reduced motion: every scene in its final state, nothing hidden
- [ ] Keyboard: tab through each screen; focus is always visible; board rows select with Enter

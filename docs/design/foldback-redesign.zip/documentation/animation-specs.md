# Animation specs

## Principles (learned from production sites, not invented)

These numbers come from inspecting the live CSS of Stripe, Linear and Mercury, plus Emil Kowalski's and NN/g's published guidance:

- **UI responses are fast:** 80–240 ms. Anything over about 300 ms on a click feels laggy.
- **Hover highlights appear instantly and fade out:** 0 ms in, 150 ms out (Linear's `--speed-highlightFadeIn: 0s / FadeOut: .15s`). This is the single biggest "feels native" trick.
- **Large reveals are slow and decelerate hard:** 700–900 ms on `cubic-bezier(.165,.84,.44,1)` (Stripe, Linear) or expo-out `cubic-bezier(.16,1,.3,1)`.
- **Never start from `scale(0)`:** start at .86–.97 with opacity. Nothing appears from nothing.
- **A 2–8 px blur on enter and cross-fade** makes motion feel physical rather than blinky.
- **Enter is slower than exit:** for example, a dialog enters in 400 ms and leaves in 160 ms.
- **Animate only cheap properties:** `transform`, `opacity`, `filter`, `clip-path`. Never `width`, `height`, `top` or `all`. The one exception is the board's Now marker, which animates `left` inside an absolutely positioned overlay (no reflow of siblings).
- **Under `prefers-reduced-motion: reduce`:** every animation and transition is ~0 ms and every scene rests in its final, composed state.
- **The Pay page has no decorative motion.** Only the 160 ms state fade.

## Tokens (`components.css` §0)

| Token | Value | Use |
|---|---|---|
| `--ease-out-quad` | `cubic-bezier(.25,.46,.45,.94)` | colour and background changes |
| `--ease-out-quart` | `cubic-bezier(.165,.84,.44,1)` | scroll reveals, meters, bars |
| `--ease-out-expo` | `cubic-bezier(.16,1,.3,1)` | hero, arrows, focus line, thumbs |
| `--ease-drawer` | `cubic-bezier(.32,.72,0,1)` | dialogs, sheets |
| `--ease-in-out` | `cubic-bezier(.645,.045,.355,1)` | the Now marker glide, ambient drift |
| `--ease-in` | `cubic-bezier(.55,0,1,.45)` | exits |
| `--ease-spring` | `cubic-bezier(.34,1.56,.64,1)` | tag pop, square fill (only these) |
| `--d-press` | 80 ms | `:active` scale |
| `--d-1 … --d-6` | 100, 160, 240, 400, 700, 900 ms | see the tables below |
| `--stagger` | 70 ms | lists, bars |

Framer Motion equivalents (only if approved): press `whileTap={{ scale: .97 }}` with `{ type: "spring", stiffness: 400, damping: 30 }`; reveals `{ duration: .7, ease: [.165,.84,.44,1] }`; tag pop `{ type: "spring", stiffness: 500, damping: 18 }`; layout `{ type: "spring", stiffness: 500, damping: 40 }`.

## Catalogue

### Global
| Name | Trigger | Properties | From → to | Duration / ease | Notes |
|---|---|---|---|---|---|
| Page transition | same-origin navigation | opacity, translateY | old: → 0, −6 px · new: 0, +10 px → 1, 0 | 180 ms in · 380 ms quart | CSS `@view-transition { navigation: auto }`. No JS. Next.js App Router: use the View Transitions API in `router.push` |
| Reveal | element enters viewport (IO, 12% threshold, −12% bottom margin) | opacity, translateY, blur | 0, 18 px, 6 px → 1, 0, 0 | 700 / 900 ms quart, delay `i × 70 ms` | Runs once (unobserve). Variants: `left` (−24 px x), `scale` (.96) |
| Wipe | as above | clip-path | `inset(0 0 100% 0)` → `inset(0)` | 900 ms quart | For headings and images |
| Scroll progress | page scroll | scaleX | 0 → 1 | linear, `animation-timeline: scroll(root)` | Pure CSS, ignored where unsupported |
| Ambient light | always (hero, sign-in art) | translate, scale | ±6 vw, .92–1.12 | 24–32 s in-out, alternate | Two or three blurred radial blobs. Paused under reduced motion |

### Buttons and controls
| Name | Trigger | Detail |
|---|---|---|
| Press | `:active` | `scale(.97)` in 80 ms, release 240 ms expo. Icon buttons .94, chips .98 |
| Arrow nudge | hover | `.btn__arrow` translateX 3 px, 240 ms expo |
| Sun slide | hover | `background-position` 0% → 60% over 400 ms quart, plus a glow shadow |
| Sun sheen | hover | a white 30%-wide band travels −100% → 100%, 900 ms quart, once per hover |
| Line hover | hover | inset 1 px shadow plus 4% tint, 160 ms |
| Link underline | hover | `background-size` 0 → 100% (1 px), 240 ms quart |
| Nav underline | hover / current | scaleX 0 → 1, origin left on enter and right on leave, 400 ms expo |
| Focus line | `:focus-within` on a field | 2 px blue, scaleX 0 → 1 from the centre, 400 ms expo |
| Error shake | failed submit | translateX −6, 5, −3, 0 px over 360 ms |
| Copy morph | click | cross-fade with ±6 px, .96 scale, 3 px blur, 240 ms. Revert after 1.6 s |
| Segmented thumb | click | translateX + width, 400 ms expo |
| Tabs ink | click | translateX + width, 400 ms expo. The panel enters from +10 px x with 2 px blur |
| Menu icon | toggle | two lines rotate into an X, 400 ms expo |
| Nav sheet | toggle | clip-path wipe down 400 ms drawer. Links −8 px → 0, staggered 40 ms after 80 ms |
| Fold lift | hover on `.fold` | `--fold-size` 14 → 22 px (28 → 40), 400 ms expo, `@property`-interpolated |

### Landing
| Moment | Detail |
|---|---|
| Headline word rise | Each word sits in an `overflow:hidden` mask. Inner span: translateY 105%, blur 8 px, opacity 0 → none. Transform 1000 ms expo, blur 800 ms quart, opacity 600 ms. Delay `120 + i × 55 ms` |
| Hero sequence | Words (0–600 ms) → panel scales in (`--i:4`, 280 ms delay) → lead, CTAs, note, trust (`--i` 6–10) |
| Panel tilt and spotlight | pointermove: `--ry = (x−.5) × 8°`, `--rx = (.5−y) × 6°`, follow 160 ms quad. Leave: return over 900 ms expo. Spotlight opacity 200 ms in, 500 ms out. Disabled for touch and reduced motion |
| Hold lands (t = 2.8 s) | Maya's tag → Held with pop (520 ms spring). Square fills (560 ms spring). Count 3 → 4. The orange row bar fades out (400 ms). "1 to go" → "Everyone's in" with pop. Meter .75 → 1 (700 ms quart). Total counts $240.00 → $320.00 over 900 ms (quartic ease-out, tabular mono so digits don't jitter). Replay resets and runs again after 900 ms |
| Countdown | ticks once per second, mono tabular |
| Phone scene | Sticky 100 vh inside a 230 vh section (180 vh on phones). JS writes `--p` = scroll progress (rAF-throttled). The phone uses rotateX 22° → 0, rotateY −26° → 0, rotateZ 6° → 0 and scale .86 → 1. "hold" slides right and "don't pay" slides left, each 55% of its width. The caption fades in from p = .25. At p > .62 Maya → Held (pop), square fills, count 4 of 4, CTA fades out 160 ms, and the held receipt rises 8 px in 400 ms. Scrolling back reverses it |
| Steps line | A 1 px ink line scaleY = `--p` of the list. Each step dot fills 300 ms after it reveals |
| Squares assemble | Each navy square starts offset (±100–140 px) and rotated (±8–14°) and settles as `--p` → 1. The open square breathes (3.2 s, opacity/scale) |
| Kept / Released | The blocks start ±40% apart and meet as `--p` → 1 |
| Board peek | Bars grow (700 ms quart, 70 ms stagger) when 40% visible |

### New plan
| Moment | Detail |
|---|---|
| Read the plan | Button disabled, label "Reading…". The terms panel switches to the skeleton with the four-square loader. Result after the request (1.6 s in the mockup) |
| State switch | Panel content enters with 8 px rise and 3 px blur, 400 ms expo |
| Terms list | Rows rise in (240 ms expo) with a 60 ms stagger |
| Evidence | Hovering a term: the matching `<mark>` highlight grows from a 30% underline to a full block (400 ms expo) plus a 2 px halo. Leave reverses it |
| Table row | Hover background instantly, 150 ms out. The arrow slides in from −6 px (240 ms) |
| Dialog | Backdrop 240 ms in / 160 ms out. Panel 400 ms drawer in / 160 ms ease-in out. Bottom sheet on phones |

### Board
| Moment | Detail |
|---|---|
| Bars | Grow on load and on every state change (see the catalogue) |
| Now marker | `left` glides over 900 ms in-out when the demo clock advances or a proposal is approved |
| Status tag | Pops on state change |
| Row select | Instant background, plus the Person card body re-enters (400 ms blur-rise) |
| Live dot | The Collecting ring expands over 2 s, infinitely (the only looping element in the app) |
| Assistant | Typing (three squares bouncing 1.2 s, staggered 150 ms) appears for about 1.1 s, then the message enters (400 ms expo). Tool lines are static |

### Pay
- Only the state cross-fade: opacity 0 → 1 in 160 ms. No tilt, ambient light, reveals or scroll motion. A confirming state uses the four-square loader, which is information, not decoration.

## Implementation notes
- **Reveal gating:** hide only when JS is present (`html.js [data-reveal]`), so content is always visible without JS or before hydration. In React, add the `js` class in the root layout script before paint.
- **Retargeting:** use transitions (not keyframes) for anything a user can trigger repeatedly. A transition retargets mid-flight; a keyframe animation restarts.
- **Restarting a keyframe** (pop, shake): remove the class, force a reflow (`void el.offsetWidth`), then add it again.
- **`will-change`:** only on the phone, the scene words and tilt panels. Never set it globally.
- **Scroll work:** one passive scroll listener and one rAF per frame, writing a single custom property per scene. CSS does the rest.
- **Reduced motion:** the global guard in `components.css` sets durations to 0.01 ms, and scenes set `--p: 1`.

# Component specs

Class names refer to `design-system/components.css`. Sizes are in px at the 16 px root. Every colour is a token in `colors.css`. Never hard-code a hex value in a component.

## Logo `.logo`
- Two inline blocks, `Fold` and `back`. Font Plex Sans 600, letter-spacing −0.04em, height 1.6em.
- `Fold`: sky background, black text, top-right fold 0.3em (navy flap). `back`: black background, white text, bottom-right fold 0.3em (sky flap). In the dark theme `back` turns white with black text.
- Sizes: 20 px in navs, 17 px on Pay, 28 px (`.logo--lg`) in marketing.
- Never animate, recolour or outline the logo. On sky it must sit on a light ground (the nav glass); see `assets/logo-light.png`.

## Buttons `.btn`
| Variant | Class | Fill / text | Hover | Use |
|---|---|---|---|---|
| Sun | `.btn--sun` | sun gradient, black, 600 | gradient slides 60%, glow `--sun-glow`, one sheen pass (900 ms) | The single action that matters on the view |
| Ink | `.btn--ink` | black / white (inverted in dark) | `#262626` | Default primary |
| Line | `.btn--line` | transparent, 1 px ink border | border visually doubles (inset shadow), 4% tint | Secondary |
| Blue | `.btn--blue` | `#0070E0` / white | `#005FC0` | PayPal-context links only |
| Ghost | `.btn--ghost` | transparent | 6% tint | Tertiary (Dismiss) |
| On sky | `.btn--on-sky` | transparent, black border | 40% white fill | Secondary on sky bands |
| Link | `.btn--link` | link blue, no box | underline grows left→right (240 ms) | Inline actions |

- Sizes: `--sm` 36 h, 16 px padding, 14 px text. Default 44 h, 20 px padding, 15 px text. `--lg` 52 h, 24 px padding, 16 px text. `--block` is full width with the label left and the arrow right.
- Radius 0, always.
- Arrow: `<span class="btn__arrow">→</span>`, last child, nudges 3 px on hover.
- Press: `scale(.97)` in 80 ms, release over 240 ms on expo-out.
- Focus: `--focus-ring` (2 px page-colour gap + 2 px blue).
- Loading: `aria-busy="true"`, `disabled`, label becomes the progress verb ("Reading…", "Signing in…"), a 14 px spinner replaces the arrow. Width must not change. Reserve it with `min-width` if the verb is shorter.
- Disabled: 42% opacity, no shadow, `cursor: not-allowed`.
- Icon-only `.btn-icon`: 44×44, hover tint appears instantly and fades out over 150 ms, press `scale(.94)`.

## Morph label `.morph`
Two stacked children, idle and done. `data-state="done"` cross-fades: outgoing goes up 6 px, incoming comes from below 6 px, both with 3 px blur, 240 ms. Return to idle after 1600 ms. Used for Copy → Copied.

## Fields `.field`
- Anatomy: `.field__label` (14/500) → `.field__control` (relative wrapper) → `.input` or `.textarea` → `.field__help` (12) or `.field__error` (14, red, with icon).
- Input: 48 h, `--layer` fill, 1 px bottom rule `#6F6F6F`, radius 0, padding 0 16. Hover: `--layer-hover`. Focus: white fill, 1 px inset line, plus a **2 px blue line drawn from the centre** (`.field__control::after`, scaleX 0→1, 400 ms expo).
- Error: `.field--error` turns the line red and leaves it drawn. The message rises in over 240 ms. On submit failure, the form gets `.shake` (360 ms, 3 swings, max 6 px).
- Textarea: min 220 h, 16 px padding, line-height 1.6, vertical resize only.
- Password: a Show/Hide text button inside the control (`.password-toggle`), 40 h.
- Every field has a visible label. Placeholders are examples, never labels.

## Tags `.tag`
- 22 h (26 for `--lg`), padding 0 8, radius 3, 12/600.
- Tones: `--waiting` grey, `--held` blue, `--kept` green, `--released` outline, `--failed` red, `--attention` yellow with black text, `--outline` (Sandbox, Sample, Guest chip), `--sun` (1 to go; only once per view).
- The word always comes from `lib/status.ts`. Tone is never the only signal.
- Live dot `.tag__live`: only on Collecting. A 6 px dot with a ring that expands over 2 s.
- Arrival `.is-pop`: scale .86→1 with 2 px blur, 520 ms spring (overshoot 1.56). Play it only when a status changes, never on page load.

## Chips
- `.chip`: 30 h, layer fill, radius 3. Optional `.chip__initial`, an 18 px sky square with a 5 px fold. Used for People.
- `.chip--action`: suggestion buttons. Square, 1 px line border; the border darkens instantly on hover. Press `scale(.98)`.

## Avatar `.avatar`
A sky square with a navy 7 px fold at the top right. Initials 12/600, black. 28 px default, 44 px `--lg`. Never round. This is the logo fold at small scale.

## Panels `.panel`
- Solid: white, 1 px `--line`, radius 8, `--shadow-2`.
- `--glass`: 62% white, `blur(22px) saturate(180%)`, 1 px 72% white border, inset 1 px top highlight, `--shadow-3`. **Only over colour** (sky field, ambient light, navy). Over plain white, use solid.
- `--raised`: `--shadow-3` (the terms panel, so it reads as "the result").
- Parts: `__head` (14/18 padding, hairline below, 15/600 title + caption right), `__body` (18), `__foot`.
- Optional behaviours: `data-spotlight` (radial light follows the cursor, 420 px, 55% white) and `data-tilt` (rotateX/Y up to ±3°/±4°, 1400 px perspective; returns over 900 ms expo).

## Fold `.fold`
A clip-path corner with a triangle flap (`--fold-flap` colour). `--fold-size` 14 px (28 for `--lg`); on hover it animates to 22 (40) px over 400 ms expo, using `@property` so it actually interpolates. `--br` folds the bottom-right corner instead. Use on brand blocks only (outcome cards, art squares), not on working UI.

## Navigation
- Marketing `.site-nav.site-nav--fixed`: fixed, 64/68 h, frosted (55% white → 86% after 8 px of scroll, plus a hairline and a soft shadow). Links 15/500 with an underline that sweeps in from the left and out to the right (400 ms expo). Under 900 px: a menu button (two lines morph into an X), and `.nav-sheet` wipes down with `clip-path` (400 ms drawer curve) with links staggered 40 ms.
- App `.app-header`: sticky, 60 h, frosted. Left to right:
  - Logo
  - Tagline (hidden under 1100)
  - Breadcrumbs (hidden under 768)
  - User chip (avatar, name, Guest chip)
  - Reset demo data (line, sm)
  - Sign out (link)

## Tables `.table` in `.table-wrap`
- The wrap has a 1 px border, radius 8 and `--shadow-1`. The header is 13/500 grey on `--bg-subtle`. Rows are 56 h with hairlines.
- The whole row is clickable (`data-href`). Hover: `--layer-selected` appears instantly and fades out over 150 ms. A `→` slides in from −6 px.
- Columns: Plan (title 500 + 13 px subline), Status tag, Holds (squares + mono "3 of 4 held"), Total (mono, right-aligned), Type tag, go arrow. Total and Type hide under 600.

## Hold progress `.squares`, `.meter`
- One square per person, 12 px (16 `--lg`, 28 `--xl`), 4 px gap. Held squares are blue. The open square is a 2 px **orange** inset outline, the only orange in its component. When a square fills it plays a 560 ms spring from .7.
- Meter: 4 h track `--layer-hover`, blue fill `scaleX(var(--v))`, 700 ms quart.

## Board
- Grid: a person column (188 px, sticky left, white) plus N day columns. Header 44 h, sticky top, 13/500. Today's column header is darker.
- Rows: 60 h, focusable (`tabindex=0`, Enter/Space selects). Hover and selected use `--layer-selected`; selected adds a 3 px ink bar on the left.
- Bars (`.bar`): 30 h, radius 3, 12/600 word inside, positioned with `left`/`width` in % of the day area. Held is blue, Waiting is grey stripes, Kept green, Released outlined. They grow in from the left (`scaleX .04→1`, 700 ms quart, 70 ms stagger) on first view and on state change. Hover: brightness 1.08 and a lift shadow.
- Markers: 2 px lines. Now is blue and glides (`left`, 900 ms ease-in-out) when the demo clock moves. Deadline is orange. Grace ends is dashed ink. Proposed is dashed blue. Labels sit in the 44 px footer band; Now's label sits left of its line and Deadline's right, so they never overlap.
- Caption row: a helper sentence plus a legend.

## Person card
Avatar-lg, name 20/500, tags (status + type), amount right (mono 18). A definition list (38% / 62%, 11 px rows, hairlines): Authorization (mono or "No hold yet"), Hold expires or Grace, Pay link (mono). Actions only when payable: Copy pay link (ink sm, morph) and Open pay link (line sm, ↗). Selection change: the body re-enters with a 400 ms blur-rise. Empty: "Select a person on the schedule."

## Assistant card
- Messages: user on the right, ink with radius 10 10 2 10. Assistant on the left, layer with radius 10 10 10 2. System lines centred, 12 px grey. Each message enters with 8 px rise, .98 scale and 2 px blur over 400 ms.
- Tool line: mono 12, an L-shaped connector, for example "Simulated Mon 9 Nov, 6:00pm PT".
- Draft: white block with a 2 px sky left border, text plus a Copy button.
- Proposal: white card, radius 8. Label 14/500, preview sentence, Approve (ink sm) and Dismiss (ghost sm).
- Typing: three 6 px squares bouncing in sequence. Show it after 300 ms of waiting, never instantly.
- Composer: input plus a square Send button, flush.
- Unavailable: a warning callout replaces the suggestions; the composer stays.

## Callouts and banners
`.callout` uses a 3 px left bar, 14/16 padding and an icon. Tones: info (blue-50), success (green 9%), warn (yellow), danger (red 8%), neutral (layer + grey bar, used for Released). `.banner` is full width and yellow, with black text and a black action on the right (the Paused state).

## Dialog
Backdrop navy 38% with a 6 px blur. Panel: max 460 wide, radius 12, `--shadow-4`, 24 padding. Title h3, body muted, actions right (secondary then primary). Enter: translateY(12)/scale(.96) → none, 400 ms drawer curve. Exit: 160 ms ease-in. Under 600 px it becomes a bottom sheet (slides from 100%, actions stacked full width, safe-area padding). Focus moves to the first action, Escape closes, and focus returns to the opener.

## Skeleton and loaders
- `.skel`: 12 px bars (18 for titles, 22 for tags), radius 2, a shimmer sweep every 1.4 s (none under reduced motion). Use it **only** when the result's layout is known (the terms list).
- `.loader-squares`: four 8 px squares lighting in sequence, the brand loader for "Reading…" and "Confirming with PayPal…".
- `.spinner`: a 16 px ring, only inside buttons.

## Segmented control
Layer track with 3 px padding and buttons 32 h, 13/500. A white thumb (shadow-1) slides to the pressed button (400 ms expo, translateX + width). Scrolls horizontally on phones. Used for the mockup state switchers and suitable for any 2–5 option toggle.

## Footer `.site-footer`
Sun gradient with an 18% multiply grain, black text 14. Logo (marketing only), sandbox line, and the theme toggle on the right (line sm, black). The theme toggle lives only here, never in the header.

## Empty states
A 2×2 outline square glyph (the last square outlined in orange), an h3 title, one muted sentence, and one action (a link). Copy: "Your plan appears here" (terms), "No plans yet" (list).
